#ifndef SHEEP_H
#define SHEEP_H

#include "Animal.h"

class Sheep : public Animal {
    public:
    Sheep();
    // ~Sheep();

    void sound();
};

#endif // SHEEP_H