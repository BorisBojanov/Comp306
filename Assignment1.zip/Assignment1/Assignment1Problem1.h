﻿// CMakeComp306AssignmentONE.h : Include file for standard system include files,
// or project specific include files.

#pragma once

#include <iostream>
#include <iomanip>

