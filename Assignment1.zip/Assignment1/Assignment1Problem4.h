//Assignment1Problem4.h

#pragma once

#include <iostream>
#include <string>
#include <cctype>